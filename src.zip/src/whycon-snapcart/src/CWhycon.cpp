#include "CWhycon.h"
#define PI 3.14159265

/*manual calibration can be initiated by pressing 'r' and then clicking circles at four positions (0,0)(fieldLength,0)...*/
void CWhycon::manualcalibration(){
    if (currentSegmentArray[0].valid){
        STrackedObject o = objectArray[0];
        moveOne = moveVal;

        //object found - add to a buffer
        if (calibStep < calibrationSteps) calibTmp[calibStep++] = o;

        //does the buffer contain enough data to calculate the object position
        if (calibStep == calibrationSteps){
            o.x = o.y = o.z = 0;
            for (int k = 0;k<calibrationSteps;k++){
                o.x += calibTmp[k].x;
                o.y += calibTmp[k].y;
                o.z += calibTmp[k].z;
            }
            o.x = o.x/calibrationSteps;	
            o.y = o.y/calibrationSteps;	
            o.z = o.z/calibrationSteps;
            if (calibNum < 4){
                calib[calibNum++] = o;
            }

            //was it the last object needed to establish the transform ?
            if (calibNum == 4){
                //calculate and save transforms
                trans->calibrate2D(calib,fieldLength,fieldWidth);
                trans->calibrate3D(calib,fieldLength,fieldWidth);
                calibNum++;
                numMarkers = wasMarkers;
                trans->saveCalibration(calibDefPath.c_str());
                trans->transformType = lastTransformType;
                detectorArray[0]->localSearch = false;
            }
            calibStep++;
        }
    }
}

/*finds four outermost circles and uses them to set-up the coordinate system - [0,0] is left-top, [0,fieldLength] next in clockwise direction*/
void CWhycon::autocalibration() {

    bool saveVals = true;

    for (int i = 0;i<numMarkers;i++){
        if (detectorArray[i]->lastTrackOK == false) saveVals=false;
    }

    if (saveVals){
        int index[] = {0,0,0,0};	
        int maxEval = 0;
        int eval = 0;
        int sX[] = {-1,+1,-1,+1};
        int sY[] = {+1,+1,-1,-1};

        for (int b = 0;b<4;b++){
            maxEval = -10000000;
            for (int i = 0;i<numMarkers;i++){
                eval = 	sX[b]*currentSegmentArray[i].x +sY[b]*currentSegmentArray[i].y;
                if (eval > maxEval){
                    maxEval = eval;
                    index[b] = i;
		    indexGUI[b] = i;
                }
            }
        }

        // printf("INDEX: %i %i %i %i\n",index[0],index[1],index[2],index[3]);

        for (int i = 0;i<4;i++){
            if (calibStep <= autoCalibrationPreSteps) calib[i].x = calib[i].y = calib[i].z = 0;
            calib[i].x+=objectArray[index[i]].x;
            calib[i].y+=objectArray[index[i]].y;
            calib[i].z+=objectArray[index[i]].z;
        }

        calibStep++;

        if (calibStep == autoCalibrationSteps){

            for (int i = 0;i<4;i++){
                calib[i].x = calib[i].x/(autoCalibrationSteps-autoCalibrationPreSteps);
                calib[i].y = calib[i].y/(autoCalibrationSteps-autoCalibrationPreSteps);
                calib[i].z = calib[i].z/(autoCalibrationSteps-autoCalibrationPreSteps);
            }

            trans->calibrate2D(calib,fieldLength,fieldWidth);
            trans->calibrate3D(calib,fieldLength,fieldWidth);
            calibNum++;
            numMarkers = wasMarkers;
            trans->saveCalibration(calibDefPath.c_str());
            trans->transformType = lastTransformType;
            autocalibrate = false;

	    // Se muestra un mensaje con los valores de cada vértice y se muestra en pantalla como mensaje al usuario
    	    ROS_INFO("Se ha completado la calibracion automatica. Los puntos de los vertices de la zona de trabajo son: \n\nV(0,0): 			(%f, %f)\nV(fieldLength,0): 		(%f, %f)\nV(0,fieldWidth): 		(%f, %f)\nV(fieldLength,fieldWidth): 	(%f, %f)\n", trans->transform(currentSegmentArray[index[0]]).x, trans->transform(currentSegmentArray[index[0]]).y,trans->transform(currentSegmentArray[index[1]]).x, trans->transform(currentSegmentArray[index[1]]).y,trans->transform(currentSegmentArray[index[2]]).x, trans->transform(currentSegmentArray[index[2]]).y,trans->transform(currentSegmentArray[index[3]]).x, trans->transform(currentSegmentArray[index[3]]).y);

        }

	// Cada vez que se recalcule los vértices de la zona de trabajo, se actualiza la variable objectArrayWorkZone y currentSegmentArrayWorkZone, utilizadas para los datos de la zona de trabajo
 	objectArrayWorkZone[0] = trans->transform(currentSegmentArray[indexGUI[0]]); 	objectArrayWorkZone[0].ID = -2;
 	objectArrayWorkZone[1] = trans->transform(currentSegmentArray[indexGUI[1]]); 	objectArrayWorkZone[1].ID = -2;
 	objectArrayWorkZone[2] = trans->transform(currentSegmentArray[indexGUI[2]]); 	objectArrayWorkZone[2].ID = -2;
 	objectArrayWorkZone[3] = trans->transform(currentSegmentArray[indexGUI[3]]); 	objectArrayWorkZone[3].ID = -2;
 	currentSegmentArrayWorkZone[0] = currentSegmentArray[indexGUI[0]]; 		currentSegmentArrayWorkZone[0].ID = -2;
 	currentSegmentArrayWorkZone[1] = currentSegmentArray[indexGUI[1]]; 		currentSegmentArrayWorkZone[1].ID = -2;
 	currentSegmentArrayWorkZone[2] = currentSegmentArray[indexGUI[2]]; 		currentSegmentArrayWorkZone[2].ID = -2;
 	currentSegmentArrayWorkZone[3] = currentSegmentArray[indexGUI[3]]; 		currentSegmentArrayWorkZone[3].ID = -2;
 
    }
}

/* Método que procesa las funciones que tienen cada tecla */
void CWhycon::processKeys(){

    // Este bucle procesa el clic del raton, principalmente para la calibración manual
    while (SDL_PollEvent(&event)){
        if (event.type == SDL_MOUSEBUTTONDOWN){
            if (calibNum < 4 && calibStep > calibrationSteps){
                calibStep = 0;
                trans->transformType = TRANSFORM_NONE;
            }
            if (numMarkers > 0){
                currentSegmentArray[numMarkers-1].x = event.motion.x*guiScale; 
                currentSegmentArray[numMarkers-1].y = event.motion.y*guiScale;
                currentSegmentArray[numMarkers-1].valid = true;
                detectorArray[numMarkers-1]->localSearch = true;
            }
        }
    }

    // A partir de este punto, detecta las pulsaciones del teclado
    keys = SDL_GetKeyState(&keyNumber);
    bool shiftPressed = keys[SDLK_RSHIFT] || keys[SDLK_LSHIFT];
    bool pPressed = keys[SDLK_p];

    // Program control - (s)top, (p)ause+move one frame and resume (borrar)

    // Se procesan las diferentes teclas con diferentes acciones. 
    if (keys[SDLK_ESCAPE]) stop = true;
    if (keys[SDLK_SPACE] && lastKeys[SDLK_SPACE] == false){ moveOne = 100000000; moveVal = 10000000;};
    if (keys[SDLK_p] && lastKeys[SDLK_p] == false) {moveOne = 1; moveVal = 0;}
    if (keys[SDLK_m] && lastKeys[SDLK_m] == false) printf("SAVE %02f %02f %02f %02f %02f %02f %02f\n",objectArray[0].x,objectArray[0].y,objectArray[0].z,objectArray[0].d,currentSegmentArray[0].m0/currentSegmentArray[0].m1, currentSegmentArray[0].m0,currentSegmentArray[0].m1);
    if (keys[SDLK_n] && lastKeys[SDLK_n] == false) printf("SEGM %02f %02f %02f %02f %02f\n",currentSegmentArray[0].x,currentSegmentArray[0].y,currentSegmentArray[0].m0/currentSegmentArray[0].m1,currentSegmentArray[0].m0,currentSegmentArray[0].m1);
    if (keys[SDLK_s] && lastKeys[SDLK_s] == false) image->saveBmp();

    // Si se pulsa la tecla "P" a la vez que se pulsa un número del 1-8, se almacena la trayectoria pintada de ese robot en la carpeta "documentos".
    if (  (	(keys[SDLK_1] && lastKeys[SDLK_1] == false) || 
		(keys[SDLK_2] && lastKeys[SDLK_2] == false) || 
		(keys[SDLK_3] && lastKeys[SDLK_3] == false) || 
		(keys[SDLK_4] && lastKeys[SDLK_4] == false)) && pPressed) {

        FILE* demo;	// pointer demo to FILE

        int idSelected = 0;

        // En función de la tecla que se pulse, se selecciona un ID.
        if 		(keys[SDLK_1]) { idSelected = 1; }
        else if 	(keys[SDLK_2]) { idSelected = 2; }
        else if 	(keys[SDLK_3]) { idSelected = 3; }
        else if 	(keys[SDLK_4]) { idSelected = 4; }

        // En función del ID seleccionado, nos traemos la lista donde se han almacenado los datos. Puede estar completa o vacía.
        dataPath = gui->getDataPath(idSelected);
	dataPathTime = gui->getDataPathTime(idSelected);

        // Si la lista de datos tiene algun dato, entra aquí y crea un fichero en blanco donde guardar los datos de la lista
        if (dataPath.size() > 1) {
		
	    if 	    (idSelected == 1) { demo = fopen("/home/chris/catkin_ws/src/whycon-snapcart/documentos/rutaRobot_1.txt", "w+"); }
            else if (idSelected == 2) { demo = fopen("/home/chris/catkin_ws/src/whycon-snapcart/documentos/rutaRobot_2.txt", "w+"); }
            else if (idSelected == 3) { demo = fopen("/home/chris/catkin_ws/src/whycon-snapcart/documentos/rutaRobot_3.txt", "w+"); }
            else if (idSelected == 4) { demo = fopen("/home/chris/catkin_ws/src/whycon-snapcart/documentos/rutaRobot_4.txt", "w+"); }

	    int i = 1;
 
		if (demo != NULL) {

		    // Las primeras lineas del archivo son la fecha a la que se ha generado y una leyenda
		    //fprintf(demo, "Fichero de datos generado en la fecha: %s\n", std::ctime(&end_time));
	    	    fprintf(demo, "pos_x pos_y angle(º) time(s)\n");

		    printf("\n");
		    ROS_INFO("Generando archivo de ruta para el robot con ID: %i ...", idSelected);

		    // Se recorre la lista mientras se pushean los datos obtenidos en el archivo creado anteriormente.
		    while (i<dataPath.size()){
			currentSegmentArrayPath[i].x     = dataPath[i][0];
			currentSegmentArrayPath[i].y     = dataPath[i][1];
			currentSegmentArrayPath[i].v0    = dataPath[i][2];
			currentSegmentArrayPath[i].v1    = dataPath[i][3];
			currentSegmentArrayPath[i].m0    = dataPath[i][4];
			currentSegmentArrayPath[i].m1    = dataPath[i][5];
			currentSegmentArrayPath[i].angle = dataPath[i][6];

			objectArrayPath[i] = trans->transform(currentSegmentArrayPath[i]);
			fprintf(demo, "%f %f %f %f\n", objectArrayPath[i].x, objectArrayPath[i].y, currentSegmentArrayPath[i].angle, dataPathTime[i] - secs0);

			i++;
		    }
		
		    ROS_INFO("Archivo rutaRobot_%i.txt generado en la carpeta /home/chris/catkin_ws/src/whycon-snapcart/documentos.\n", idSelected);

		    // Finalmente, se cierra el fichero donde se han almacenado todos los datos
		    fclose(demo);

		}

        } else { 
	    ROS_INFO("No se han registrado datos de ruta para el robot con ID: %i. ", idSelected); 
	}
  	    
    }

    // Calibración automática (busca las 4 balizas más externas y las usa para establecer el sistema de coordenadas)
    if (keys[SDLK_a] && lastKeys[SDLK_a] == false) { 
	firstCalibrationDone = true;
	calibStep = 0; 
	lastTransformType=trans->transformType; 
	wasMarkers = numMarkers; 
	autocalibrate = true; 
	ROS_INFO("Realizando calibrado automatico de la zona de trabajo..."); 
	trans->transformType=TRANSFORM_NONE;
    }; 

    // Calibración manual (se define mediante clics el valor de cada vértice de la zona de trabajo)
    if (keys[SDLK_r] && lastKeys[SDLK_r] == false) { calibNum = 0; wasMarkers=numMarkers; numMarkers = 1;}

    //debugging - toggle drawing coordinates and debugging results results
    if (keys[SDLK_l] && lastKeys[SDLK_l] == false) drawCoords = drawCoords == false;

    if (keys[SDLK_d] && lastKeys[SDLK_d] == false){ 
        for (int i = 0;i<numMarkers;i++){
            detectorArray[i]->draw = detectorArray[i]->draw==false;
            detectorArray[i]->debug = detectorArray[i]->debug==false;
            decoder->debugSegment = decoder->debugSegment==false;
        }
    }

    // Posibles transformaciones para usar. La '2D' es la principal en este proyecto
    // if (pPressed == false) {if (keys[SDLK_1] && lastKeys[SDLK_1] == false) trans->transformType = TRANSFORM_NONE;}
    // if (pPressed == false) {if (keys[SDLK_2] && lastKeys[SDLK_2] == false) trans->transformType = TRANSFORM_2D;}
    // if (pPressed == false) {if (keys[SDLK_3] && lastKeys[SDLK_3] == false) trans->transformType = TRANSFORM_3D;}

    // Menú de ayuda
    if (keys[SDLK_h] && lastKeys[SDLK_h] == false) displayHelp = displayHelp == false; 
    
    // Publicacion en Gazebo
    if (keys[SDLK_g] && lastKeys[SDLK_g] == false) sendToGazebo = sendToGazebo == false;

    // Controlar el número de robots que va a detectar el programa
    if (keys[SDLK_PLUS] && lastKeys[SDLK_PLUS] == false) {
	if (numMarkers < 4) numMarkers++;
	else numMarkers = numMarkers + 2;
    }
    if (keys[SDLK_EQUALS] && lastKeys[SDLK_EQUALS] == false) {
	if (numMarkers < 4) numMarkers++;
	else numMarkers = numMarkers + 2;
    }
    if (keys[SDLK_MINUS] && lastKeys[SDLK_MINUS] == false) {
	if (numMarkers < 4) numMarkers--;
	else numMarkers = numMarkers - 2;
    }
    if (keys[SDLK_KP_PLUS] && lastKeys[SDLK_KP_PLUS] == false) {
	if (numMarkers < 4) numMarkers++;
	else numMarkers = numMarkers + 2;
    }
    if (keys[SDLK_KP_MINUS] && lastKeys[SDLK_KP_MINUS] == false) {
	if (numMarkers < 4) numMarkers--;
	else numMarkers = numMarkers - 2;
    }
    if (keys[SDLK_KP_MINUS] && lastKeys[SDLK_KP_MINUS] == false) {
	if (numMarkers < 4) numMarkers--;
	else numMarkers = numMarkers - 2;
    }
    
    // Activación de la grabación de ruta de todos los robots en pantalla
    if (keys[SDLK_t] && lastKeys[SDLK_t] == false) {

	drawPath = drawPath == false;
	if (drawPath) {
	    struct timeval start0, stop;
	    secs0 = 0;
	    gettimeofday(&start0, NULL);
	    secs0 = (double)(start0.tv_usec) / 1000000 + (double)(start0.tv_sec);
	}
    }

    // Activa/desactiva las lineas de la zona de trabajo
    if (keys[SDLK_z] && lastKeys[SDLK_z] == false) drawWorkZone = drawWorkZone == false;

    // Se almacenan los diferentes estados de cada tecla para controlarlas
    memcpy(lastKeys,keys,keyNumber);
}

void CWhycon::cameraInfoCallback(const sensor_msgs::CameraInfoConstPtr& msg){
    if(msg->K[0] == 0)
    {
        ROS_ERROR_ONCE("ERROR: Camera is not calibrated!");
        return;
    }
    else if(msg->K[0] != intrinsic.at<float>(0,0) || msg->K[2] != intrinsic.at<float>(0,2) || msg->K[4] != intrinsic.at<float>(1,1) ||  msg->K[5] != intrinsic.at<float>(1,2))
    {
        for(int i = 0; i < 5; i++) distCoeffs.at<float>(i) = msg->D[i];
        int tmpIdx = 0;
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 3; j++){
                intrinsic.at<float>(i, j) = msg->K[tmpIdx++];
            }
        }
        trans->updateParams(intrinsic, distCoeffs);
    }
}

void CWhycon::imageCallback(const sensor_msgs::ImageConstPtr& msg){
    //setup timers to assess system performance
    CTimer timer;
    timer.reset();
    timer.start();

    CTimer globalTimer;
    globalTimer.reset();
    globalTimer.start();

    // check if readjusting of camera is needed
    if (image->bpp != msg->step/msg->width || image->width != msg->width || image->height != msg->height){
        delete image;
        ROS_INFO("Readjusting image format from %ix%i %ibpp, to %ix%i %ibpp.",
                image->width, image->height, image->bpp, msg->width, msg->height, msg->step/msg->width);
        image = new CRawImage(msg->width,msg->height,msg->step/msg->width);
        if(useGui){
            while(image->height/guiScale > screenHeight || image->height/guiScale > screenWidth) guiScale = guiScale*2;
            if(gui == NULL){
                gui = new CGui(msg->width, msg->height, guiScale, fontPath.c_str());
            }else{
                delete gui;
                gui = new CGui(msg->width, msg->height, guiScale, fontPath.c_str());
            }
        }
    }

    memcpy(image->data,(void*)&msg->data[0],msg->step*msg->height);

    numFound = numStatic = 0;
    timer.reset();

    // track the robots found in the last attempt 
    for (int i = 0;i<numMarkers;i++){
        if (currentSegmentArray[i].valid){
            lastSegmentArray[i] = currentSegmentArray[i];
            currentSegmentArray[i] = detectorArray[i]->findSegment(image,lastSegmentArray[i]);
            currInnerSegArray[i] = detectorArray[i]->getInnerSegment();
        }
    }

    // search for untracked (not detected in the last frame) robots 
    for (int i = 0;i<numMarkers;i++){
        if (currentSegmentArray[i].valid == false){
            lastSegmentArray[i].valid = false;
            currentSegmentArray[i] = detectorArray[i]->findSegment(image,lastSegmentArray[i]);
            currInnerSegArray[i] = detectorArray[i]->getInnerSegment();
        }
        if (currentSegmentArray[i].valid == false) break;		//does not make sense to search for more patterns if the last one was not found
    }
	
    float dmin=1000;

    // perform transformations from camera to world coordinates
    for (int i = 0; i<numMarkers; i++){
        if (currentSegmentArray[i].valid){
            int step = image->bpp;
            int pos;
	    double x, y, result;

	    pos = ((int)currentSegmentArray[i].x+((int)currentSegmentArray[i].y)*image->width);
            image->data[step*pos+0] = 255;
            image->data[step*pos+1] = 0;
            image->data[step*pos+2] = 0;

            pos = ((int)currInnerSegArray[i].x+((int)currInnerSegArray[i].y)*image->width);
            image->data[step*pos+0] = 0;
            image->data[step*pos+1] = 255;
            image->data[step*pos+2] = 0;

	    // En este punto se setean los datos transformados al espacio de trabajo actual de todos los robots de la imagen.
            objectArray[i] = trans->transform(currentSegmentArray[i]);
	   
	    // En el caso de que se seleccione la opcion "Identify" en el rqt_configure, entramos en el bloque donde se identifican los diferentes robots.
            if(identify){

		

		// En función de la relación, se identifica con un número u otro.
		if (indexGUI[0] == i || indexGUI[1] == i || indexGUI[2] == i || indexGUI[3] == i){
		    objectArray[i].ID = currentSegmentArray[i].ID = -2;
		} else if ( currentSegmentArray[i].m0/currInnerSegArray[i].m0 < 1.90 || currentSegmentArray[i].m0/currInnerSegArray[i].m0 > 2.1) {
		    objectArray[i].ID = currentSegmentArray[i].ID = -1;
		}

		// ROS_INFO("objectArray[i].ID: %i", objectArray[i].ID);
		// ROS_INFO("Ext/int: %f", currentSegmentArray[i].m0/currInnerSegArray[i].m0);
		
		// Este bloque calcula el ángulo al que se encuentra el robot. Descartamos los que sean ID = 0, es decir, balizas delimitadoras de la zona de trabajo.
		if (objectArray[i].ID != -2){

		    // ROS_INFO("Objeto[i]: %d", i);
		    // ROS_INFO("(%f,%f) Objeto[i]: %d", objectArray[i].x, objectArray[i].y, i);
		    // ROS_INFO("Ext/int: %f", currentSegmentArray[i].m0/currInnerSegArray[i].m0);
		    // ROS_INFO("indexGUI[0]: %d\n", indexGUI[0], "indexGUI[1]: %d\n", indexGUI[1], "indexGUI[2]: %d\n", indexGUI[2], "indexGUI[3]: %d\n", indexGUI[3]);

		    // Para cada iteración, se inicializa estas variables a estos valores
		    float distanciaElipseCirculoMenor = 1000;
		    int jMenor = 0;

		    // En este bucle se recorre todas las balizas circulares pequeñas que estan junto a las principales, las cuales indican el ID y la dirección.
		    for (int j = 0; j<numMarkers; j++) {
 		        if (currentSegmentArray[j].valid){

			  // Se almacena en esta variable la distancia del centro de la principal al centro de cada baliza pequeña.
			  float distanciaElipseCirculoAux = sqrt((currentSegmentArray[i].x-currentSegmentArray[j].x)*(currentSegmentArray[i].x-currentSegmentArray[j].x) + (currentSegmentArray[i].y-currentSegmentArray[j].y)*(currentSegmentArray[i].y-currentSegmentArray[j].y));

			  // Se comprueba si la distancia desde la baliza X a una de las balizas con ID=0 es menor que la anterior, se guarda el indice de esa baliza
			  if (distanciaElipseCirculoAux < distanciaElipseCirculoMenor && distanciaElipseCirculoAux < distanciaBalizaDireccion && currentSegmentArray[i].m0 > currentSegmentArray[j].m0) {

				// ROS_INFO("distanciaElipseCirculoAux: %f", distanciaElipseCirculoAux);
				// ROS_INFO("Objeto[i]: %d", i);
				// ROS_INFO("Objeto[j]: %d", j);
				// ROS_INFO("(X,Y)[i]: (%f,%f)", objectArray[i].x, objectArray[i].y);
				// ROS_INFO("currentSegmentArray[i].m0: %f, currentSegmentArray[i].m1: %f", currentSegmentArray[i].m0, currentSegmentArray[i].m1);
				// ROS_INFO("currInnerSegArray[i].m0: %f, currInnerSegArray[i].m1: %f", currInnerSegArray[i].m0, currInnerSegArray[i].m1);
				// ROS_INFO("currentSegmentArray[j].m0: %f, currentSegmentArray[j].m1: %f", currentSegmentArray[j].m0, currentSegmentArray[j].m1);
				// ROS_INFO("currInnerSegArray[j].m0: %f, currInnerSegArray[j].m1: %f", currInnerSegArray[j].m0, currInnerSegArray[j].m1);

				float relacionBalizaDireccion = currentSegmentArray[j].m0/currInnerSegArray[j].m0;
				// ROS_INFO("relacionBalizaDireccion del objeto %i es: %f\n", j, relacionBalizaDireccion);

				if (relacionBalizaDireccion > 1.2 && relacionBalizaDireccion < 1.5) {
				    objectArray[i].ID = currentSegmentArray[i].ID = 1;
				} else if (relacionBalizaDireccion >= 1.5 && relacionBalizaDireccion < 1.9) {
				    objectArray[i].ID = currentSegmentArray[i].ID = 2;
				} else if (relacionBalizaDireccion >= 2.1 && relacionBalizaDireccion < 2.5) {
				    objectArray[i].ID = currentSegmentArray[i].ID = 3;
				} else {
				    objectArray[i].ID = currentSegmentArray[i].ID = 4;
				}

				jMenor = j;
				distanciaElipseCirculoMenor = distanciaElipseCirculoAux;
			  }

		        }
		    }

		    // Finalmente, se usa la jMenor, ya que esta baliza será la más cercana a la baliza robot que se encuentra en pantalla (con menor distanciaElipseCirculoAux)
		    result = -(atan2(-currentSegmentArray[jMenor].y+currentSegmentArray[i].y, currentSegmentArray[jMenor].x-currentSegmentArray[i].x)*180/PI - 180) - angleWorkZone;

		    if (result < 0) { result = result + 360;} 
		    else if (result > 360) { result = result - 360;}

		    objectArray[i].yaw = result;
		    
		}

            } else {

                float dist1 = sqrt((currInnerSegArray[i].x-objectArray[i].segX1)*(currInnerSegArray[i].x-objectArray[i].segX1)+(currInnerSegArray[i].y-objectArray[i].segY1)*(currInnerSegArray[i].y-objectArray[i].segY1));

                float dist2 = sqrt((currInnerSegArray[i].x-objectArray[i].segX2)*(currInnerSegArray[i].x-objectArray[i].segX2)+(currInnerSegArray[i].y-objectArray[i].segY2)*(currInnerSegArray[i].y-objectArray[i].segY2));

                if (dist1 < dist2) {
                    currentSegmentArray[i].x = objectArray[i].segX1;
                    currentSegmentArray[i].y = objectArray[i].segY1;
                    objectArray[i].x = objectArray[i].x1;
                    objectArray[i].y = objectArray[i].y1;
                    objectArray[i].z = objectArray[i].z1;

                } else{
                    currentSegmentArray[i].x = objectArray[i].segX2;
                    currentSegmentArray[i].y = objectArray[i].segY2;
                    objectArray[i].x = objectArray[i].x2;
                    objectArray[i].y = objectArray[i].y2;
                    objectArray[i].z = objectArray[i].z2;
                }
            }

            numFound++;

            if (currentSegmentArray[i].x == lastSegmentArray[i].x) numStatic++;

        }
    }

    //    if(numFound > 0) ROS_INFO("Pattern detection time: %i us. Found: %i Static: %i.",globalTimer.getTime(),numFound,numStatic);
    evalTime = timer.getTime();

    // publishing information about tags 
    whycon_ros::MarkerArray markerArray;
    
    // Whycon_marker should have the same header as the image received
    markerArray.header = msg->header;
    
    visualization_msgs::MarkerArray visualArray;

    for (int i = 0; i < numMarkers; i++){
        if (currentSegmentArray[i].valid){

            whycon_ros::Marker marker;

            marker.id = currentSegmentArray[i].ID;
            marker.size = currentSegmentArray[i].size;

            // Convert to ROS standard Coordinate System
            marker.position.position.x = -objectArray[i].y;
            marker.position.position.y = -objectArray[i].z;
            marker.position.position.z = objectArray[i].x;

            //double data[4] = {marker.id*100,marker.position.position.x,marker.position.position.y,marker.position.position.z}; //TODO
            double data[4] = {marker.id*10000,objectArray[i].x,objectArray[i].y,objectArray[i].z}; //TODO
            Mat descriptor = cv::Mat(cv::Size(1,4), CV_64FC1,data);
            
            // the "roll, pitch, yaw" vector (in rotation), basically this is the normal of the marker in image coords
            // as currently reported in "rotation" field
            tf::Vector3 axis_vector(0.0, 0.0, objectArray[i].yaw);

            //the "up vector" (pointing out of the camera, this is the reference the orientation is based on)
            tf::Vector3 up_vector(0.0, 0.0, 1.0);

            // the position of the marker (normalised to unit length)
            tf::Vector3 marker_pos(marker.position.position.x,marker.position.position.y,marker.position.position.z);
            marker_pos.normalize();

            // the assumption now is that the angle between the marker's position vector (pos) and the
            // normal of the marker (v2, here) always has to be an acute angle (<90), 
            // if it is not, the normal is pointing away from us and we see the "wrong side"
            // consequently, if pos * v2 > 0 we have an acute angle and the quaternion is fine
            // otherwise in pos * v2 < 0, it needs to be flipped, easiest is to just flip v2 and then compute the quaternion
            bool current_marker_is_acute;
            if (marker_pos.dot(axis_vector) > 0) current_marker_is_acute = true;
            else current_marker_is_acute = false;


            // only put in the array the whycon detections that meet the filter criterions specified
            if (useAcuteFilter){
                if (current_marker_is_acute) {
                    if (sqrt(marker.position.position.x*marker.position.position.x + marker.position.position.z*marker.position.position.z) < maxDetectionDistance) {
                        // taken from inspired by https://stackoverflow.com/a/11741520. transfrom 
                        // get the quaternion between the up_vector and the reported
                        tf::Vector3 right_vector = axis_vector.cross(up_vector);
                        right_vector.normalized();
                        tf::Quaternion quat(right_vector, -1.0*acos(axis_vector.dot(up_vector)));
                        quat.normalize();
                        geometry_msgs::Quaternion marker_orientation;
                        tf::quaternionTFToMsg(quat, marker_orientation);

                        marker.position.orientation = marker_orientation;

                        // Euler angles
                        marker.rotation.x = objectArray[i].pitch;
                        marker.rotation.y = objectArray[i].roll;
                        marker.rotation.z = objectArray[i].yaw;

                        // Generate RVIZ marker for visualisation
                        visualization_msgs::Marker visualMarker;
                        visualMarker.header = msg->header;
                        // visualMarker.header.stamp = ros::Time();
                        visualMarker.ns = "whycon";
                        visualMarker.id = (identify) ? marker.id : i;
                        visualMarker.type = visualization_msgs::Marker::SPHERE;
                        visualMarker.action = visualization_msgs::Marker::MODIFY;
                        visualMarker.pose = marker.position;
                        visualMarker.scale.x = circleDiameter;  // meters
                        visualMarker.scale.y = circleDiameter;
                        visualMarker.scale.z = 0.01;
                        visualMarker.color.r = 0.0;
                        visualMarker.color.g = 1.0;
                        visualMarker.color.b = 0.0;
                        visualMarker.color.a = 1.0;
                        visualMarker.lifetime = ros::Duration(0.2);  // sec
                        markerArray.markers.push_back(marker);
                        visualArray.markers.push_back(visualMarker);
                    }
                }

            } else {
                if (sqrt(marker.position.position.x*marker.position.position.x + marker.position.position.z*marker.position.position.z) < maxDetectionDistance) {
                    // taken from inspired by https://stackoverflow.com/a/11741520. transfrom 
                    // get the quaternion between the up_vector and the reported
                    tf::Vector3 right_vector = axis_vector.cross(up_vector);
                    right_vector.normalized();
                    tf::Quaternion quat(right_vector, -1.0*acos(axis_vector.dot(up_vector)));
                    quat.normalize();
                    geometry_msgs::Quaternion marker_orientation;
                    tf::quaternionTFToMsg(quat, marker_orientation);

                    marker.position.orientation = marker_orientation;

                    // Euler angles
                    marker.rotation.x = objectArray[i].pitch;
                    marker.rotation.y = objectArray[i].roll;
                    marker.rotation.z = objectArray[i].yaw;

                    // Generate RVIZ marker for visualisation
                    visualization_msgs::Marker visualMarker;
                    visualMarker.header = msg->header;
                    // visualMarker.header.stamp = ros::Time();
                    visualMarker.ns = "whycon";
                    visualMarker.id = (identify) ? marker.id : i;
                    visualMarker.type = visualization_msgs::Marker::SPHERE;
                    visualMarker.action = visualization_msgs::Marker::MODIFY;
                    visualMarker.pose = marker.position;
                    visualMarker.scale.x = circleDiameter;  // meters
                    visualMarker.scale.y = circleDiameter;
                    visualMarker.scale.z = 0.01;
                    visualMarker.color.r = 0.0;
                    visualMarker.color.g = 1.0;
                    visualMarker.color.b = 0.0;
                    visualMarker.color.a = 1.0;
                    visualMarker.lifetime = ros::Duration(0.2);  // sec
                    markerArray.markers.push_back(marker);
                    visualArray.markers.push_back(visualMarker);
                }
            }
        }
    }

    /*geometry_msgs::Pose start_pose;
    start_pose.position.x = 0.0;
    start_pose.position.y = 0.0;
    start_pose.position.z = 0.1;
    start_pose.orientation.x = 0.0;
    start_pose.orientation.y = 0.0;
    start_pose.orientation.z = 0.0;
    start_pose.orientation.w = 0.0;

    geometry_msgs::Twist start_twist;
    start_twist.linear.x = 0.0;
    start_twist.linear.y = 0.0;
    start_twist.linear.z = 0.0;
    start_twist.angular.x = 0.0;
    start_twist.angular.y = 0.0;
    start_twist.angular.z = 0.0;

    gazebo_msgs::ModelState modelstate;
    modelstate.model_name = (std::string) "robot";
    modelstate.reference_frame = (std::string) "world";
    modelstate.pose = start_pose;
    modelstate.twist = start_twist;*/

    // only publish if there a certain amount of markers detected that meet the conditions
    if(markerArray.markers.size() >= minDetectionsToPublish){
        markers_pub.publish(markerArray);
        visual_pub.publish(visualArray);
    }

    //draw stuff on the GUI 
    if (useGui){
        gui->drawImage(image);
        gui->drawTimeStats(evalTime,numMarkers,drawPath);
        gui->displayHelp(displayHelp);
        gui->guideCalibration(calibNum,fieldLength,fieldWidth);
    }

    // Se recorre todos los robots que se han detectado en la imagen. Si es un robot fijo, no se pinta ni entra al bucle ya que numMarkers == 0.
    for (int i = 0; i<numMarkers && useGui && drawCoords; i++){

	// Únicamente se ve la trayectoria cuando hay alguna baliza móvil en pantalla. Si no hay ninguna, no se muestra ninguna ruta, por lo de numMArkers == 0. de arriba.
        if (currentSegmentArray[i].ID != -2) {
	    currentSegmentArray[i].angle = objectArray[i].yaw;				// Se añade en el parámetro angle del objeto el resultado final del ángulo del robot
	    
	    gui->drawPath(currentSegmentArray[i], drawPath, minDistDibujado);	// Se almacena la posición X,Y,angulo, junto al tiempo, en un documento.
	
	    if (currentSegmentArray[i].valid) {
		gui->drawStats(currentSegmentArray[i].minx-30,currentSegmentArray[i].maxy,objectArray[i],trans->transformType == TRANSFORM_2D);
	    }

	}

	// Se publica el robot[i] en gazebo para que se vea el mundo virtual.
    	if (objectArray[i].ID != -2 && sendToGazebo) gazebo_publish(objectArray[i]);
	
	// Se publica el workZone en gazebo
	if (sendToGazebo) gazebo_publish_workzone(objectArrayWorkZone);
    }

    // Usando la variable indexGUi (almacena el identificador de las balizas de la zona de trabajo), se pinta la zona de trabajo.
    if (drawWorkZone){
	    gui->drawWorkZone(currentSegmentArray[indexGUI[0]].x, currentSegmentArray[indexGUI[0]].y, currentSegmentArray[indexGUI[1]].x, currentSegmentArray[indexGUI[1]].y);
	    gui->drawWorkZone(currentSegmentArray[indexGUI[1]].x, currentSegmentArray[indexGUI[1]].y, currentSegmentArray[indexGUI[3]].x, currentSegmentArray[indexGUI[3]].y);
	    gui->drawWorkZone(currentSegmentArray[indexGUI[3]].x, currentSegmentArray[indexGUI[3]].y, currentSegmentArray[indexGUI[2]].x, currentSegmentArray[indexGUI[2]].y);
	    gui->drawWorkZone(currentSegmentArray[indexGUI[2]].x, currentSegmentArray[indexGUI[2]].y, currentSegmentArray[indexGUI[0]].x, currentSegmentArray[indexGUI[0]].y);
	}

    // Para cada baliza que supone un vértice de la zona de trabajo, se pinta sus datos.
    if (firstCalibrationDone) {
	gui->drawStats(currentSegmentArrayWorkZone[0].x,currentSegmentArrayWorkZone[0].y,objectArrayWorkZone[0],trans->transformType == TRANSFORM_2D);
	gui->drawStats(currentSegmentArrayWorkZone[1].x,currentSegmentArrayWorkZone[1].y,objectArrayWorkZone[1],trans->transformType == TRANSFORM_2D);
	gui->drawStats(currentSegmentArrayWorkZone[2].x,currentSegmentArrayWorkZone[2].y,objectArrayWorkZone[2],trans->transformType == TRANSFORM_2D);
	gui->drawStats(currentSegmentArrayWorkZone[3].x,currentSegmentArrayWorkZone[3].y,objectArrayWorkZone[3],trans->transformType == TRANSFORM_2D);
    }

    //establishing the coordinate system by manual or autocalibration
    if (autocalibrate && numFound == numMarkers) autocalibration();
    if (calibNum < 4) manualcalibration();

    // empty for-cycle that isn't used even in master orig version
    //for (int i = 0;i<numMarkers;i++){
    //	if (currentSegmentArray[i].valid) printf("Object %i %03f %03f %03f\n",i,objectArray[i].x,objectArray[i].y,objectArray[i].z);
    //}

    //printf("\n---------------------------------------\n");

    //gui->saveScreen(runs);
    if (useGui) gui->update();
    if (useGui) processKeys();
}

// Método que publica en gazebo las 4 balizas que componen el espacio de trabajo
void CWhycon::gazebo_publish_workzone(STrackedObject *object){

    if (sendToGazebo) {
	for (int i = 0; i<4; i++){

	    gazebo_msgs::ModelState modelstate2;
	    geometry_msgs::Pose start_pose;

	    if      (abs(round(object[i].x)) == 0 && abs(round(object[i].y)) == 0) 			{ modelstate2.model_name = "WH_Base_00"; /*printf("V00");*/ }
	    else if (abs(round(object[i].x)) == 0 && abs(round(object[i].y)) == fieldWidth) 		{ modelstate2.model_name = "WH_Base_0Y"; /*printf("V0Y");*/ }
	    else if (abs(round(object[i].x)) == fieldLength && abs(round(object[i].y)) == 0) 		{ modelstate2.model_name = "WH_Base_X0"; /*printf("VX0");*/ }
	    else if (abs(round(object[i].x)) == fieldLength && abs(round(object[i].y)) == fieldWidth) 	{ modelstate2.model_name = "WH_Base_XY"; /*printf("VXY");*/ }

 	    start_pose.position.x = abs(round(object[i].x));
	    start_pose.position.y = abs(round(object[i].y));
	    start_pose.position.z = 0.0;
	    start_pose.orientation = tf::createQuaternionMsgFromYaw(0);

	    modelstate2.reference_frame = (std::string) "world";
	    modelstate2.pose = start_pose;

	    gazebo_pub.publish(modelstate2);

	}
    }

}

// Método que publica en gazebo cada robot detectado en pantalla
void CWhycon::gazebo_publish(STrackedObject object){

    if (sendToGazebo) {
	gazebo_msgs::ModelState modelstate1;
	geometry_msgs::Pose start_pose;

	if      (object.ID == 1) 	modelstate1.model_name = "andruino_1";
	else if (object.ID == 2) 	modelstate1.model_name = "andruino_2";
	else if (object.ID == 3) 	modelstate1.model_name = "andruino_3";
	else if (object.ID == 4) 	modelstate1.model_name = "andruino_4";
	else 				modelstate1.model_name = "undefined";

	start_pose.position.x = object.x;
	start_pose.position.y = object.y;
	start_pose.position.z = 0.0;

	// Como la orientacion se le debe pasar en radianes, se convierte los grados a radianes y se le suma 180º más ya que se pone al revés.
	start_pose.orientation = tf::createQuaternionMsgFromYaw(-object.yaw*PI/180 + 3.142); 

	modelstate1.reference_frame = (std::string) "world";
	modelstate1.pose = start_pose;

	gazebo_pub.publish(modelstate1);
    }
}

// dynamic parameter reconfiguration
void CWhycon::reconfigureCallback(CWhycon *whycon, whycon_ros::whyconConfig& config, uint32_t level){
    ROS_INFO("[Reconfigure Request]\n"
            "numMarkers %d circleDiam %lf identify %d\n"
            "initCircularityTolerance %lf finalCircularityTolerance %lf\n"
            "areaRatioTolerance %lf centerDistTolerance %lf centerDistToleranceAbs %lf\n",
            config.numMarkers, config.circleDiameter, config.identify,\
            config.initialCircularityTolerance, config.finalCircularityTolerance,\
            config.areaRatioTolerance,config.centerDistanceToleranceRatio,config.centerDistanceToleranceAbs);

    whycon->numMarkers = (config.numMarkers > whycon->maxMarkers) ? whycon->maxMarkers : config.numMarkers;
    whycon->fieldLength = config.fieldLength;  
    whycon->minDistDibujado = config.minDistDibujado;
    whycon->fieldWidth = config.fieldWidth;
    whycon->angleWorkZone = config.angleWorkZone;
    whycon->distanciaBalizaDireccion = config.distanciaBalizaDireccion;
    whycon->dM1 = config.dM1;
    whycon->identify = config.identify;
    whycon->circleDiameter = config.circleDiameter / 100.0;

    whycon->trans->reconfigure(config.circleDiameter);

    for (int i = 0;i<whycon->maxMarkers;i++) whycon->detectorArray[i]->reconfigure(\
            config.initialCircularityTolerance, config.finalCircularityTolerance,\
            config.areaRatioTolerance,config.centerDistanceToleranceRatio,\
            config.centerDistanceToleranceAbs, config.identify, config.minSize);
}

// cleaning up
CWhycon::~CWhycon(){
    ROS_DEBUG("Releasing memory.");
    free(calibTmp);
    free(objectArray);
    free(objectArrayWorkZone);
    free(objectArrayPath);
    free(currInnerSegArray);
    free(currentSegmentArray);
    free(currentSegmentArrayWorkZone);
    free(currentSegmentArrayPath);
    free(lastSegmentArray);

    delete image;
    if (useGui) delete gui;
    for (int i = 0;i<maxMarkers;i++) delete detectorArray[i];
    free(detectorArray);
    delete trans;
    delete decoder;
    delete n;
}

CWhycon::CWhycon(){
    imageWidth = 640;
    imageHeight = 480;
    circleDiameter = 0.122;
    fieldLength = 1.00;
    fieldWidth = 1.00;
    minDistDibujado = 5;
    angleWorkZone = 0.00;
    distanciaBalizaDireccion = 0.00;
    dM1 = 0.00;
    firstCalibrationDone = false;

    identify = false;
    numMarkers = 0;
    numFound = 0;
    numStatic = 0;

    idBits = 0;
    idSamples = 360;
    hammingDist = 1;

    stop = false;
    moveVal = 1;
    moveOne = moveVal; 
    useGui = true;
    guiScale = 1;
    keyNumber = 10000;
    keys = NULL;
    displayHelp = false;
    drawCoords = true;
    sendToGazebo = false;
    drawPath = false;
    runs = 0;
    evalTime = 0;
    screenWidth= 1920;
    screenHeight = 1080;

    calibNum = 5;
    calibTmp = (STrackedObject*) malloc(calibrationSteps * sizeof(STrackedObject));
    calibStep = calibrationSteps+2;
    autocalibrate = false;
    lastTransformType = TRANSFORM_3D;
    wasMarkers = 1;

    useAcuteFilter = false;
    maxDetectionDistance = 100;
    minDetectionsToPublish = 1;

}

void CWhycon::init(char *fPath, char *calPath){
    n = new ros::NodeHandle("~");
    image_transport::ImageTransport it(*n);
    image = new CRawImage(imageWidth,imageHeight, 3);

    // loading params and args from launch file
    fontPath = fPath;
    calibDefPath = calPath;
    n->param("useGui", useGui, true);
    n->param("idBits", idBits, 3);
    n->param("idSamples", idSamples, 360);
    n->param("hammingDist", hammingDist, 1);
    n->param("maxMarkers", maxMarkers, 100);
    n->param("useAcuteFilter", useAcuteFilter, false); //only whycons within an acute angle repect the camera will be published
    n->param("maxDetectionDistance",maxDetectionDistance,100); // whycon futher away than this distance won't be published
    n->param("minDetectionsToPublish", minDetectionsToPublish, 1); //minimum amount of detected fiducial before start publishing

    moveOne = moveVal;
    moveOne  = 0;

    objectArray = (STrackedObject*) malloc(maxMarkers * sizeof(STrackedObject));
    objectArrayWorkZone = (STrackedObject*) malloc(maxMarkers * sizeof(STrackedObject));
    objectArrayPath = (STrackedObject*) malloc(maxMarkers * sizeof(STrackedObject));
    currInnerSegArray = (SSegment*) malloc(maxMarkers * sizeof(SSegment));
    currentSegmentArray = (SSegment*) malloc(maxMarkers * sizeof(SSegment));
    currentSegmentArrayWorkZone = (SSegment*) malloc(maxMarkers * sizeof(SSegment));
    currentSegmentArrayPath = (SSegment*) malloc(maxMarkers * sizeof(SSegment));
    lastSegmentArray = (SSegment*) malloc(maxMarkers * sizeof(SSegment));

    // determine gui size so that it fits the screen
    while (imageHeight/guiScale > screenHeight || imageHeight/guiScale > screenWidth) guiScale = guiScale*2;

    // initialize GUI, image structures, coordinate transformation modules
    if (useGui) gui = new CGui(imageWidth,imageHeight,guiScale, fontPath.c_str());
    trans = new CTransformation(imageWidth,imageHeight,circleDiameter, calibDefPath.c_str());
    trans->transformType = TRANSFORM_3D;		//in our case, 2D is the default

    detectorArray = (CCircleDetect**) malloc(maxMarkers * sizeof(CCircleDetect*));

    // initialize the circle detectors - each circle has its own detector instance 
    for (int i = 0;i<maxMarkers;i++) detectorArray[i] = new CCircleDetect(imageWidth,imageHeight,identify, idBits, idSamples, hammingDist);
    image->getSaveNumber();

    decoder = new CNecklace(idBits,idSamples,hammingDist);

    // initialize dynamic reconfiguration feedback
    dynSer = boost::bind(&CWhycon::reconfigureCallback, this, _1, _2);
    server.setCallback(dynSer);

    // subscribe to camera topic, publish topis with card position, rotation and ID
    subInfo = n->subscribe("/camera/camera_info", 1, &CWhycon::cameraInfoCallback, this);
    subImg = it.subscribe("/camera/image_raw", 1, &CWhycon::imageCallback, this);
    markers_pub = n->advertise<whycon_ros::MarkerArray>("/whycon_ros/markers", 1);
    visual_pub = n->advertise<visualization_msgs::MarkerArray>( "/whycon_ros/visual", 0 );
    gazebo_pub = n->advertise<gazebo_msgs::ModelState>( "/gazebo/set_model_state", 10 );

    while (ros::ok()){
        ros::spinOnce();
        usleep(30000);
        if(stop) break;
    }
}

int main(int argc,char* argv[]){
    ros::init(argc, argv, "whycon_ros");

    CWhycon *whycon = new CWhycon();
    whycon->init(argv[1], argv[2]);

    delete whycon;

    return 0;
}
